﻿Public Class Form2

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub RefreshTables(Optional ByVal q As String = "")
        sqlquery.Connection = sqlconn
        OpenCon()
        Try
            Dim adapter As New OleDb.OleDbDataAdapter
            Dim dt As New DataTable
            sqlquery.CommandText = "SELECT * FROM Enrollmentinfo WHERE ID = '" & txtSearch.Text & "'"
            adapter.SelectCommand = sqlquery
            dt.Clear()
            adapter.Fill(dt)
            DataGridView.DataSource = dt
            sqlconn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        sqlconn.Close()
    End Sub
    Private Sub LoadTables(Optional ByVal q As String = "")
        sqlquery.Connection = sqlconn
        OpenCon()
        Try
            Dim adapter As New OleDb.OleDbDataAdapter
            Dim dt As New DataTable
            sqlquery.CommandText = "SELECT * FROM Enrollmentinfo"
            adapter.SelectCommand = sqlquery
            dt.Clear()
            adapter.Fill(dt)
            DataGridView.DataSource = dt
            sqlconn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        sqlconn.Close()
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call LoadTables()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        OpenCon()
        sqlquery.Connection = sqlconn
        Try
            sqlquery.CommandText = "INSERT INTO Enrollmentinfo(ID, Lastname, FirstName, MiddleName, Gender, Age, Birthdate, Yearlevel, Contactnumber, Course) VALUES('" & txtID.Text & "','" & txtLastname.Text & "', '" & txtFirstname.Text & "', '" & txtMiddlename.Text & "','" & txtGender.Text & "','" & txtAge.Text & "','" & txtBirthdate.Text & "','" & txtYearlevel.Text & "','" & txtContactnumber.Text & "','" & txtCourse.Text & "')"
            sqlquery.ExecuteNonQuery()
            MessageBox.Show("Successfully Registered")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        sqlconn.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Call RefreshTables()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        sqlquery.Connection = sqlconn
        OpenCon()
        Try
            sqlquery.CommandText = "UPDATE Enrollmentinfo SET  Lastname = '" & txtLastname.Text & "', Firstname = '" & txtFirstname.Text & "', Middlename = '" & txtMiddlename.Text & "', Gender ='" & txtGender.Text & "' WHERE Lastname = '" & txtSearch.Text & "'"
            sqlquery.ExecuteNonQuery()
            MessageBox.Show("Updated Record")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        sqlconn.Close()
        Call LoadTables()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        OpenCon()
        Try
            sqlquery.CommandText = "DELETE * FROM Enrollmentinfo WHERE Lastname = '" & txtSearch.Text & "'"
            sqlquery.ExecuteNonQuery()
            MessageBox.Show("Record Deleted")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        sqlconn.Close()
        Call LoadTables()
    End Sub

    Private Sub btnEXIT_Click(sender As Object, e As EventArgs) Handles btnEXIT.Click
        Me.Close()

    End Sub
End Class