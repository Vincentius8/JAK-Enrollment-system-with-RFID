﻿Public Class Form1
    Dim counter As Integer = 1

    Private Sub LgnBTN_Click(sender As Object, e As EventArgs) Handles LgnBTN.Click

        Dim username, password As String
        username = TextBox1.Text
        password = TextBox2.Text

        If username = "Admin" And password = "Admin" Then
            MsgBox("Access Granted")
            Form2.Show()

        ElseIf username <> "Admin" And password = "Admin" Then
            MsgBox("Invalid Username")

        ElseIf username = "Admin" And password <> "Admin" Then
            MsgBox("Invalid Password")
        Else
            MsgBox("Access Denied")


        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class